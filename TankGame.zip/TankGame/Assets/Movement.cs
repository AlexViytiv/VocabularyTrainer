﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour
{

    public float movespeed = 7.0f;
    public float drag = 0.1f;
    public float terminalRotationSpeed = 60.0f;
    public VirtualJoystick moveJoystick;

    private Rigidbody controller;
    private Transform camTransform;

    private void Start()
    {
        controller = GetComponent<Rigidbody>();
        controller.maxAngularVelocity = terminalRotationSpeed;
        controller.drag = drag;

        camTransform = Camera.main.transform;
    }

    private void Update()
    {
        Vector3 dir = Vector3.zero;

        dir.x = -Input.GetAxis("Vertical");
        dir.z = Input.GetAxis("Horizontal");

        if (dir.magnitude > 1)
            dir.Normalize();

        if(moveJoystick.InputDirection != Vector3.zero)
        {
            dir = moveJoystick.InputDirection;
        }

        // Rotate vector dir with camera
        Vector3 rotateDir = camTransform.TransformDirection(dir);
        rotateDir = new Vector3(rotateDir.x, 0, rotateDir.z);
        rotateDir = rotateDir.normalized * dir.magnitude;

        transform.Rotate(0, rotateDir.x/2, 0);
        transform.Translate(0, 0, rotateDir.z/2);
        //controller.AddForce(rotateDir * movespeed);

    }

    /*
	// Use this for initialization
	void Start () {
    }

    public float horizontalSpeed = 2.0F;
    public float verticalSpeed = 2.0F;

    // Update is called once per frame
    void Update () {



        //float x = horizontalSpeed * Input.GetAxis("Mouse X") * 2.0f;
        float x = Input.GetAxis("Horizontal") * Time.deltaTime * 150.0f;
        float z = Input.GetAxis("Vertical") * Time.deltaTime * 10.0f;

        transform.Rotate(0, x, 0);
        transform.Translate(0, 0, z);
    }
    */
}
